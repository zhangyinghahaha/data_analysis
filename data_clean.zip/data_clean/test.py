# -*- coding: utf-8 -*-
"""
Created on Tue Apr 10 22:51:03 2018

@author: zhangying
"""

import numpy as np

a = np.arange(100).reshape(5,20)
np.savetxt("a.csv",a,fmt="%.1f",delimiter=",")
#1、读入数据
#2、结构化数据
#3、查看需要处理的部分
#4、清理数据
#5、写出数据